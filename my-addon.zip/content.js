chrome.runtime.onMessage.addListener(function (response, sendResponse) {
    alert(response);
});