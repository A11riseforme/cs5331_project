---
layout: default
title: type
published: true
mainMaxWidth: 50rem;
---

Using the `type` argument you can define what sort of control you want to create for your setting.

For a list of available control types please refer to the [controls](../controls) page.
