<?php
 global $onetone_animated, $onetone_section_id;
 $i                   = $onetone_section_id ;
 $section_title       = onetone_option( 'section_title_'.$i );
 $section_menu        = onetone_option( 'menu_title_'.$i );
 $section_content     = onetone_option( 'section_content_'.$i );
 $show_all_btn        = onetone_option( 'section_show_all_btn_'.$i );

  if( !isset($section_content) || $section_content=="" ) 
	  $section_content = onetone_option( 'sction_content_'.$i );
?>
        
<?php if($section_title){ ?>
	<h2 class="section-title <?php echo 'section_title_'.$i;?>"><?php echo esc_attr($section_title);?></h2>
<?php } ?>
            <div class="home-section-content <?php echo 'section_content_'.$i;?>">
            <?php 
			if(function_exists('Form_maker_fornt_end_main'))
             {
                 $section_content = Form_maker_fornt_end_main($section_content);
              }
			 echo do_shortcode(wp_kses_post($section_content));
			?>
            </div>
