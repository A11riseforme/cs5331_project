<?php
echo onetone_get_default_slider(); 